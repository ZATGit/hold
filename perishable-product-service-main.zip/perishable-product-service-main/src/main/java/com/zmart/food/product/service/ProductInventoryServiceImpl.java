package com.zmart.food.product.service;

import com.zmart.food.product.cache.CacheEvictCreateOrUpdate;
import com.zmart.food.product.cache.CacheEvictDelete;
import com.zmart.food.product.cache.CacheableAllProducts;
import com.zmart.food.product.cache.CacheableItemCode;
import com.zmart.food.product.cache.CacheableItemName;
import com.zmart.food.product.cache.CacheableNameOrCode;
import com.zmart.food.product.cache.CacheableQuality;
import com.zmart.food.product.cache.NoCache;
import com.zmart.food.product.dto.ProductDto;
import com.zmart.food.product.dto.ProductMapper;
import com.zmart.food.product.dto.Request.ProductByItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameOrItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameRequest;
import com.zmart.food.product.dto.Request.ProductByQualityRequest;
import com.zmart.food.product.dto.Request.ProductCreateOrUpdateRequest;
import com.zmart.food.product.dto.Request.ProductDeleteRequest;
import com.zmart.food.product.dto.Request.ProductFutureDateRequest;
import com.zmart.food.product.dto.Response.ProductAllProductsResponse;
import com.zmart.food.product.dto.Response.ProductByItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameOrItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameResponse;
import com.zmart.food.product.dto.Response.ProductByQualityResponse;
import com.zmart.food.product.dto.Response.ProductCreateOrUpdateResponse;
import com.zmart.food.product.dto.Response.ProductDeleteResponse;
import com.zmart.food.product.dto.Response.ProductFutureDateResponse;
import com.zmart.food.product.entity.Product;
import com.zmart.food.product.exception.AppIllegalArgumentException;
import com.zmart.food.product.repository.ProductProjectionIdsAndNamesOnly;
import com.zmart.food.product.repository.ProductRepository;
import com.zmart.food.product.utils.ProductUtils;
import com.zmart.food.product.utils.QualityRequestEnum;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.zmart.food.product.dto.ProductMapper.PRODUCT_MAPPER;
import static com.zmart.food.product.exception.ExceptionUtils.checkProductSpecialCaseAllowed;
import static com.zmart.food.product.service.ProductInventoryServiceImplHelper.updateEachProductQualityAndFutureDate;
import static com.zmart.food.product.utils.UtilConstants.PRODUCTS_STRING;

@Slf4j
@CacheConfig(cacheNames = PRODUCTS_STRING)
@Service
public class ProductInventoryServiceImpl implements ProductInventoryService {

    private final ProductRepository productRepository;

    @Autowired
    public ProductInventoryServiceImpl(
            final ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @CacheableAllProducts
    public ProductAllProductsResponse getAllProductsInventory() {
        final List<Product> result = productRepository.findAll();
        return ProductAllProductsResponse.builder()
                .productDtoList(PRODUCT_MAPPER.productEntityListToProductDtoList(result))
                .count(result.size())
                .build();
    }

    @NoCache(reason = "expected date change with repeated arg")
    public ProductFutureDateResponse getAllProductsForFutureDateInventory(
            final ProductFutureDateRequest request) {
        final List<ProductDto> productDtoList = getAllProductsInventory().productDtoList();
        final List<ProductDto> result =
                productDtoList
                        .stream()
                        .parallel()
                        .map(p -> updateEachProductQualityAndFutureDate(p, request.dayOffset()))
                        .toList();
        return ProductFutureDateResponse.builder()
                .productDtoList(result)
                .count(result.size())
                .build();
    }

    @CacheableItemName
    public ProductByItemNameResponse getProductByItemNameInventory(
            final ProductByItemNameRequest request) {
        final Product result = Optional.ofNullable(
                productRepository.findByItemNameIgnoreCase(request.itemName())).orElseGet(Product::new);
        return ProductByItemNameResponse.builder()
                .productDto(PRODUCT_MAPPER.productEntityToProductDto(result))
                .build();
    }

    @CacheableItemCode
    public ProductByItemCodeResponse getProductByItemCodeInventory(
            final ProductByItemCodeRequest request) {
        final Product result = Optional.ofNullable(
                productRepository.findByItemCodeIgnoreCase(request.itemCode())).orElseGet(Product::new);
        return ProductByItemCodeResponse.builder()
                .productDto(PRODUCT_MAPPER.productEntityToProductDto(result))
                .build();
    }

    /**
     * Find all itemName & itemCode containing given params
     *
     * <p><b>Use case:</b> Search "Organic Spinach" when item names could be "Farm2Table Organic
     * Spinach" or "Organic Spinach Extra Fresh!"
     *
     * <p><b>Use case:</b> Search for all organic foods by item code with "Org" prefix
     *
     * @param request
     * @return List of Products
     */
    @CacheableNameOrCode
    public ProductByItemNameOrItemCodeResponse getProductByItemNameOrItemCodeInventory(
            final ProductByItemNameOrItemCodeRequest request) {
        final List<Product> result =
                productRepository
                        .findByItemCodeContainsOrItemNameContainsIgnoreCaseOrderByItemCodeAsc(
                                request.itemCode(), request.itemName());
        return ProductByItemNameOrItemCodeResponse.builder()
                .productDtoList(PRODUCT_MAPPER.productEntityListToProductDtoList(result))
                .count(result.size())
                .build();
    }

    @CacheableQuality
    public ProductByQualityResponse getAllProductsByQualityInventory(
            final ProductByQualityRequest request) {
        final Pageable pageable = PageRequest.of(0, request.limit() == null ? Integer.MAX_VALUE : request.limit(),
                Sort.Direction.valueOf(request.orderByAscOrDesc().toUpperCase(Locale.ROOT)),
                request.orderByAttribute());
        final List<Product> result = productRepository.findByQuality(request.quality(), pageable);
        return ProductByQualityResponse.builder()
                .productDtoList(PRODUCT_MAPPER.productEntityListToProductDtoList(result))
                .count(result.size())
                .build();
    }

    @CacheEvictCreateOrUpdate
    public ProductCreateOrUpdateResponse createOrUpdateProductsInventory(
            @NotNull final ProductCreateOrUpdateRequest request) {
        final List<Product> productList = PRODUCT_MAPPER
                .createOrUpdateRequestMappingToProductList(request.productList());
        final List<Product> createdOrUpdateProductList = new ArrayList<>();
        productList
                .forEach(
                        product -> {
                            checkProductSpecialCaseAllowed(product.getSpecialCase());
                            createdOrUpdateProductList.add(product);
                            productRepository.save(product);
                        });
        return ProductCreateOrUpdateResponse.builder()
                .productDtoList(PRODUCT_MAPPER
                        .productEntityListToProductDtoList(createdOrUpdateProductList))
                .count(createdOrUpdateProductList.size())
                .build();
    }

    @CacheEvictDelete
    public ProductDeleteResponse deleteProductsInventory(
            final ProductDeleteRequest productDeleteRequest) {
        final List<ProductProjectionIdsAndNamesOnly> deletableProductIdsResult =
                productRepository.findAllByIdIn(
                        productDeleteRequest.idList(), ProductProjectionIdsAndNamesOnly.class);
        final List<Long> deletableProductIds =
                deletableProductIdsResult.stream()
                        .map(ProductProjectionIdsAndNamesOnly::getId)
                        .toList();
        productRepository.deleteAllById(deletableProductIds);
        log.debug("Deleted ids: " + deletableProductIds);
        return ProductDeleteResponse.builder()
                .deletedProducts(deletableProductIdsResult)
                .count(deletableProductIdsResult.size())
                .build();
    }
}
