package com.zmart.food.product.exception;

import jakarta.validation.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.Nullable;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import static com.zmart.food.product.exception.AppHttpMessageNotReadableException.NOT_READABLE_CLASS_NAME;
import static com.zmart.food.product.exception.AppHttpMessageNotReadableException.NOT_READABLE_ILLEGAL_ARG_MSG;
import static com.zmart.food.product.exception.AppIllegalArgumentException.ILLEGAL_ARG_MSG;
import static com.zmart.food.product.exception.AppInternalServerErrorException.INTERNAL_SERVER_ERROR_CLASS_NAME;
import static com.zmart.food.product.exception.AppInternalServerErrorException.INTERNAL_SERVER_ERROR_MSG;
import static com.zmart.food.product.exception.AppNullPointerException.NULL_POINTER_MSG;
import static com.zmart.food.product.exception.AppSpecialCaseException.SPECIAL_CASE_MSG;
import static com.zmart.food.product.exception.ExceptionUtils.filterExceptionTraceElements;
import static com.zmart.food.product.exception.ExceptionUtils.getConstraintViolationMessage;
import static com.zmart.food.product.exception.ExceptionUtils.getDeclaringClass;
import static com.zmart.food.product.exception.ExceptionUtils.getExceptionName;
import static com.zmart.food.product.exception.ExceptionUtils.getLineNumber;
import static com.zmart.food.product.exception.ExceptionUtils.getMessage;
import static com.zmart.food.product.exception.ExceptionUtils.getMethodCaller;
import static com.zmart.food.product.exception.ExceptionUtils.getMethodName;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

/**
 * Controller advice to translate the server side exceptions to client-friendly json structures.
 */
@ControllerAdvice
// Suppress unused private field & replace preferred to replaceAll warnings
@SuppressWarnings({"java:S1068", "java:S5361"})
public class ExceptionHandlerAdvice extends ResponseEntityExceptionHandler {

    private final AppNullPointerException appNullPointerException;
    private final AppIllegalArgumentException appIllegalArgumentException;
    private final AppInternalServerErrorException appInternalServerErrorException;
    private final AppSpecialCaseException appSpecialCaseException;

    @Autowired
    ExceptionHandlerAdvice(
            final AppNullPointerException appNullPointerException,
            final AppIllegalArgumentException appIllegalArgumentException,
            final AppInternalServerErrorException appInternalServerErrorException,
            final AppSpecialCaseException appSpecialCaseException) {
        this.appNullPointerException = appNullPointerException;
        this.appIllegalArgumentException = appIllegalArgumentException;
        this.appInternalServerErrorException = appInternalServerErrorException;
        this.appSpecialCaseException = appSpecialCaseException;
    }

    @ExceptionHandler({Exception.class})
    public ResponseEntity<Object> handleException(final Exception ex) {
        if (ex instanceof AppNullPointerException) {
            return handleBadRequest(ex, NULL_POINTER_MSG);
        } else if (ex instanceof AppIllegalArgumentException) {
            return handleBadRequest(ex, ILLEGAL_ARG_MSG);
        } else if (ex instanceof AppSpecialCaseException) {
            return handleBadRequest(ex, SPECIAL_CASE_MSG);
        } else if (ex instanceof ConstraintViolationException conEx) {
            return handleBadRequest(ex, getConstraintViolationMessage(conEx));
        } else {
            return handleExceptionInternal(ex);
        }
    }

    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            final HttpMessageNotReadableException ex,
            final HttpHeaders headers,
            final HttpStatusCode status,
            final WebRequest request) {
        final StackTraceElement[] filteredTrace = filterExceptionTraceElements(ex);
        final ExceptionBuilder exBuilder =
                ExceptionBuilder.builder()
                        .code(String.valueOf(status))
                        .message(NOT_READABLE_ILLEGAL_ARG_MSG)
                        .exception(NOT_READABLE_CLASS_NAME)
                        .cause(ExceptionBuilder.Cause.builder()
                                .message(getMessage(ex).split(" nested exception is")[0])
                                .declaringClass(getDeclaringClass(filteredTrace))
                                .methodName(getMethodName(filteredTrace))
                                .methodCaller(getMethodCaller(filteredTrace))
                                .lineNumber(getLineNumber(filteredTrace))
                                .build())
                        .build();
        return new ResponseEntity<>(exBuilder, status);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            final HttpRequestMethodNotSupportedException ex,
            final HttpHeaders headers,
            final HttpStatusCode status,
            final WebRequest request) {
        final ExceptionBuilder exBuilder =
                ExceptionBuilder.builder()
                        .code(String.valueOf(status))
                        .message(getMessage(ex))
                        .exception(getExceptionName(ex))
                        .cause(ExceptionBuilder.Cause.builder()
                                .build())
                        .build();
        return new ResponseEntity<>(exBuilder, status);
    }

    /**
     * Handles MethodArgumentNotValidException.
     * Thrown by hibernate-validator violations.
     * Not thrown during entity binding.
     */
    @Nullable
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            final MethodArgumentNotValidException ex, final HttpHeaders headers, final HttpStatusCode status, final WebRequest request) {
        final String message;
        if (ex.hasFieldErrors() && String.valueOf(ex.getFieldError()).contains("must only contain unique elements")) {
            message = ExceptionUtils.buildResponseForUniqueElementsViolation(ex);
        } else {
            message = ExceptionUtils.buildResponseForConstraintViolations(ex);
        }
        return handleBadRequest(ex, message);
    }

    /**
     * Handles 400 client errors that are not overridden.
     */
    protected ResponseEntity<Object> handleBadRequest(
            final Exception ex,
            final String message) {
        final HttpStatus status = BAD_REQUEST;
        final StackTraceElement[] filteredTrace = filterExceptionTraceElements(ex);
        final ExceptionBuilder exBuilder =
                ExceptionBuilder.builder()
                        .code(String.valueOf(status))
                        .message(message)
                        .exception(getExceptionName(ex))
                        .cause(ExceptionBuilder.Cause.builder()
                                .message(getMessage(ex))
                                .declaringClass(getDeclaringClass(filteredTrace))
                                .methodName(getMethodName(filteredTrace))
                                .methodCaller(getMethodCaller(filteredTrace))
                                .lineNumber(getLineNumber(filteredTrace))
                                .build())
                        .build();
        return new ResponseEntity<>(exBuilder, status);
    }

    /**
     * Handles 500 server errors.
     */
    protected ResponseEntity<Object> handleExceptionInternal(final Exception ex) {
        final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        final StackTraceElement[] filteredTrace = filterExceptionTraceElements(ex);
        final ExceptionBuilder exBuilder =
                ExceptionBuilder.builder()
                        .code(String.valueOf(status))
                        .message(INTERNAL_SERVER_ERROR_MSG)
                        .exception(INTERNAL_SERVER_ERROR_CLASS_NAME)
                        .cause(ExceptionBuilder.Cause.builder()
                                .message(getMessage(ex))
                                .declaringClass(getDeclaringClass(filteredTrace))
                                .methodName(getMethodName(filteredTrace))
                                .methodCaller(getMethodCaller(filteredTrace))
                                .lineNumber(getLineNumber(filteredTrace))
                                .build())
                        .build();
        return new ResponseEntity<>(exBuilder, status);
    }
}
