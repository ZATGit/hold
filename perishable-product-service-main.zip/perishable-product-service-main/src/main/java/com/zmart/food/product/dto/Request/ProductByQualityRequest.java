package com.zmart.food.product.dto.Request;

import com.zmart.food.product.validation.ValidPageSize;
import com.zmart.food.product.validation.ValidPositiveNumeral;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.ASC_CONST_LOWER;
import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.ASC_CONST_UPPER;
import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.DESC_CONST_LOWER;
import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.DESC_CONST_UPPER;
import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.ITEM_NAME_CONST;
import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.SELL_BY_CONST;


public record ProductByQualityRequest(
        @ValidPositiveNumeral
        Integer quality,
        @ValidPageSize
        Integer limit,
        @NotBlank
        @Pattern(
                regexp = SELL_BY_CONST + '|' + ITEM_NAME_CONST,
                message = "must match " + SELL_BY_CONST + " or " + ITEM_NAME_CONST)
        String orderByAttribute,
        @NotBlank
        @Pattern(
                regexp = ASC_CONST_LOWER + '|' + ASC_CONST_UPPER + '|' +
                        DESC_CONST_LOWER + '|' + DESC_CONST_UPPER,
                message = "must match " + ASC_CONST_LOWER + ", " + ASC_CONST_UPPER + ", " +
                        DESC_CONST_LOWER + ", or " + DESC_CONST_UPPER)
        String orderByAscOrDesc) {
}
