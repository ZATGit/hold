package com.zmart.food.config;

import com.zmart.food.product.entity.Product;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.system.SystemProperties;
import org.springframework.context.event.EventListener;
import org.springframework.core.SpringVersion;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ProductLoggingListener {

    private static final String PRODUCT = "Product";

    @EventListener(ApplicationReadyEvent.class)
    public void logPostStartup() {
        String versions = String.valueOf(
                new StringBuilder("Spring: ".concat(SpringVersion.getVersion()))
                        .append(" | ")
                        .append("JDK: ".concat(SystemProperties.get("java.version")))

        );
        log.info(versions);
        log.info("\uD83C\uDCA1 APP READY \uD83C\uDCD1");
    }

    @PrePersist
    public void logPrePersist(Product product) {
        log.trace(
                PRODUCT
                        + " \""
                        + product.getItemName()
                        + "\" "
                        + "is not present in table. --> [INSERTING]");
    }

    @PostPersist
    public void logPostPersist(Product product) {
        log.trace(
                PRODUCT + " \""
                        + product.getItemName()
                        + "\" "
                        + "--> [INSERTED]");
    }

    @PreUpdate
    public void logPreUpdate(Product product) {
        log.trace(
                PRODUCT
                        + " \""
                        + product.getItemName()
                        + "\" "
                        + "is present in table. [id: "
                        + product.getId()
                        + "] --> [UPDATING]");
    }

    @PostUpdate
    public void logPostUpdate(Product product) {
        log.trace(
                PRODUCT
                        + "\""
                        + product.getItemName()
                        + product.getId()
                        + "] --> [UPDATED]");
    }

    @PreRemove
    public void logPreRemove(Product product) {
        log.trace(PRODUCT
                + " \""
                + product.getItemName()
                + "\" [id: "
                + product.getId()
                + "] --> [REMOVING]");
    }

    @PostRemove
    public void logPostRemove(Product product) {
        log.trace(PRODUCT
                + " \""
                + product.getItemName()
                + "\" [id: "
                + product.getId()
                + "] --> [REMOVED]");
    }
}