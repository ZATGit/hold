package com.zmart.food.product.service;

import com.zmart.food.product.dto.Request.ProductByItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameOrItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameRequest;
import com.zmart.food.product.dto.Request.ProductByQualityRequest;
import com.zmart.food.product.dto.Request.ProductCreateOrUpdateRequest;
import com.zmart.food.product.dto.Request.ProductDeleteRequest;
import com.zmart.food.product.dto.Request.ProductFutureDateRequest;
import com.zmart.food.product.dto.Response.ProductAllProductsResponse;
import com.zmart.food.product.dto.Response.ProductByItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameOrItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameResponse;
import com.zmart.food.product.dto.Response.ProductByQualityResponse;
import com.zmart.food.product.dto.Response.ProductCreateOrUpdateResponse;
import com.zmart.food.product.dto.Response.ProductDeleteResponse;
import com.zmart.food.product.dto.Response.ProductFutureDateResponse;

public interface ProductInventoryService {
    /**
     * @return
     * @description Get All items.
     */
    ProductAllProductsResponse getAllProductsInventory();

    /**
     * @param day
     * @return
     * @description Get all items and their quality after ${x} days.
     */
    ProductFutureDateResponse getAllProductsForFutureDateInventory(ProductFutureDateRequest request);

    /**
     * @param quality
     * @return
     * @description Get All items quality.
     */
    ProductByQualityResponse getAllProductsByQualityInventory(ProductByQualityRequest request);

    /**
     * @param itemName
     * @return
     * @description Get item by its item name.
     */
    ProductByItemNameResponse getProductByItemNameInventory(ProductByItemNameRequest request);

    /**
     * @return
     */
    ProductByItemCodeResponse getProductByItemCodeInventory(ProductByItemCodeRequest request);

    /**
     * @param itemName
     * @param itemCode
     * @return
     */
    ProductByItemNameOrItemCodeResponse getProductByItemNameOrItemCodeInventory(
            ProductByItemNameOrItemCodeRequest request);

    /**
     * @param productList
     * @return
     */
    ProductCreateOrUpdateResponse createOrUpdateProductsInventory(
            ProductCreateOrUpdateRequest request);

    /**
     * @param productList
     * @return
     */
    ProductDeleteResponse deleteProductsInventory(ProductDeleteRequest request);
}
