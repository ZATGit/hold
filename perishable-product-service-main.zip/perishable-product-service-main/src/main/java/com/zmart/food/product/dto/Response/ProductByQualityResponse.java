package com.zmart.food.product.dto.Response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.zmart.food.product.dto.ProductDto;
import com.zmart.food.product.validation.ValidUniqueCollection;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Builder;

import java.io.Serializable;
import java.util.List;

import static com.zmart.food.product.utils.UtilConstants.PRODUCTS_STRING;


@JsonPropertyOrder({"count", "productDtoList"})
public record ProductByQualityResponse(
        @NotNull
        @PositiveOrZero
        Integer count,
        @JsonProperty(PRODUCTS_STRING)
        @ValidUniqueCollection
        List<@NotNull ProductDto> productDtoList
) implements Serializable, ProductResponse {

    //TODO: Refactor - annotating constructor instead of Type due to IntelliJ bug
    @Builder
    public ProductByQualityResponse {
    }
}
