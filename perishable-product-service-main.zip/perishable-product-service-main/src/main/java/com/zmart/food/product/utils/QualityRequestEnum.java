package com.zmart.food.product.utils;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;

// Suppresses 'unused' constructor param
@SuppressWarnings("java:S1172")
public enum QualityRequestEnum {
    SELL_BY(QualityRequestConstants.SELL_BY_CONST),
    ITEM_NAME(QualityRequestConstants.ITEM_NAME_CONST),
    ASC(QualityRequestConstants.ASC_CONST_LOWER),
    DESC(QualityRequestConstants.DESC_CONST_LOWER);

    QualityRequestEnum(final String str) {
    }

    /**
     * Used to provide validation annotations with constant enum value.
     */
    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class QualityRequestConstants {
        public static final String SELL_BY_CONST = "sellBy";
        public static final String ITEM_NAME_CONST = "itemName";
        public static final String ASC_CONST_LOWER = "asc";
        public static final String ASC_CONST_UPPER = "ASC";
        public static final String DESC_CONST_LOWER = "desc";
        public static final String DESC_CONST_UPPER = "DESC";
    }
}
