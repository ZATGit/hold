package com.zmart.food.product.dto.Request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;


public record ProductFutureDateRequest(
        @NotNull
        @PositiveOrZero
        Integer dayOffset) {
}
