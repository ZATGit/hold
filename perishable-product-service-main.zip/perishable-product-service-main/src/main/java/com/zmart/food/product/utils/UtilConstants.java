package com.zmart.food.product.utils;

import java.text.SimpleDateFormat;

public interface UtilConstants {
    String API_VERSION = "; version=1";
    String STORE_API_ENDPOINT = "/zmart/product/items";
    String PRODUCTS_STRING = "products";
    String DATA_STRING = "data";
    SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
}
