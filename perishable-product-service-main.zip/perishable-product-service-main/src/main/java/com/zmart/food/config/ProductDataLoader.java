package com.zmart.food.config;

import com.zmart.food.product.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.Date;

import static com.zmart.food.product.utils.ProductUtils.buildProductWrapper;
import static com.zmart.food.product.utils.ProductUtils.parseDateForJenkinsTimezones;

@ConditionalOnProperty(
        value = "local.database.prefill-data",
        havingValue = "on",
        matchIfMissing = true)
@Component
public class ProductDataLoader implements CommandLineRunner {

    private static final Date date = new Date();
    private final ProductRepository productRepository;

    @Autowired
    public ProductDataLoader(
            final ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public void run(final String... args) {
        final Date parsedDate = parseDateForJenkinsTimezones(date);
        productRepository.save(
                buildProductWrapper(parsedDate, "Farm2Table Organic Spinach",
                        "OrgSpinach", 10, 20, 0));
        productRepository.save(
                buildProductWrapper(parsedDate, "Corn on the cob",
                        "CornCob", 2, 1, 1));
        productRepository.save(
                buildProductWrapper(parsedDate, "Grannysmith Apple",
                        "ApplesGran", 5, 7, 0));
        productRepository.save(
                buildProductWrapper(parsedDate, "Twinkies",
                        "Twinkies", 1, 80, 3));
        productRepository.save(
                buildProductWrapper(parsedDate, "3lb Ground Beef",
                        "3lbGrBeef", 15, 20, 2));
        productRepository.save(
                buildProductWrapper(parsedDate, "Moonberries",
                        "MoonBerr", 15, 20, 0));
    }
}
