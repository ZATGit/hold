package com.zmart.food.product.controller;

import com.zmart.food.product.dto.Request.ProductByItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameOrItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameRequest;
import com.zmart.food.product.dto.Request.ProductByQualityRequest;
import com.zmart.food.product.dto.Request.ProductCreateOrUpdateRequest;
import com.zmart.food.product.dto.Request.ProductDeleteRequest;
import com.zmart.food.product.dto.Request.ProductFutureDateRequest;
import com.zmart.food.product.service.ProductInventoryService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.zmart.food.product.utils.UtilConstants.API_VERSION;
import static com.zmart.food.product.utils.UtilConstants.STORE_API_ENDPOINT;

@Slf4j
@RestController
@Validated
@RequestMapping(
        path = STORE_API_ENDPOINT,
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE + API_VERSION)
public class ProductRestController {

    private final ProductInventoryService productInventoryService;

    public ProductRestController(
            final ProductInventoryService productInventoryService) {
        this.productInventoryService = productInventoryService;
    }

    @PostMapping
    public ResponseEntity<Object> getAllProducts() {
        return new ResponseEntity<>(
                productInventoryService.getAllProductsInventory(), HttpStatus.OK);
    }

    @PostMapping("/future/day")
    public ResponseEntity<Object> getAllProductsForFutureDate(
            @RequestBody @Valid final ProductFutureDateRequest request) {
        return new ResponseEntity<>(
                productInventoryService.getAllProductsForFutureDateInventory(request),
                HttpStatus.OK);
    }

    @PostMapping("/itemname")
    public ResponseEntity<Object> getProductByItemName(
            @RequestBody @Valid final ProductByItemNameRequest request) {
        return new ResponseEntity<>(
                productInventoryService.getProductByItemNameInventory(request), HttpStatus.OK);
    }

    @PostMapping("/itemcode")
    public ResponseEntity<Object> getProductByItemCode(
            @RequestBody @Valid final ProductByItemCodeRequest request) {
        return new ResponseEntity<>(
                productInventoryService.getProductByItemCodeInventory(request), HttpStatus.OK);
    }

    @PostMapping("/itemname-or-itemcode")
    public ResponseEntity<Object> getProductByItemNameOrItemCode(
            @RequestBody @Valid final ProductByItemNameOrItemCodeRequest request) {
        return new ResponseEntity<>(
                productInventoryService.getProductByItemNameOrItemCodeInventory(request),
                HttpStatus.OK);
    }

    @PostMapping("/quality")
    public ResponseEntity<Object> getAllProductsByQuality(
            @RequestBody @Valid final ProductByQualityRequest request) {
        return new ResponseEntity<>(
                productInventoryService.getAllProductsByQualityInventory(request),
                HttpStatus.OK);
    }

    @PutMapping({"/create-or-update", "/create", "/update"})
    public ResponseEntity<Object> createOrUpdateProducts(
            @RequestBody @Valid final ProductCreateOrUpdateRequest request) {
        return new ResponseEntity<>(
                productInventoryService.createOrUpdateProductsInventory(
                        request),
                HttpStatus.OK);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<Object> deleteProducts(
            @RequestBody @Valid final ProductDeleteRequest request) {
        return new ResponseEntity<>(
                productInventoryService.deleteProductsInventory(request),
                HttpStatus.OK);
    }
}
