package com.zmart.food.product.dto.Response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.zmart.food.product.dto.ProductDto;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;

import java.io.Serializable;

import static com.zmart.food.product.utils.UtilConstants.PRODUCTS_STRING;


public record ProductByItemNameResponse(
        @NotNull
        @JsonProperty(PRODUCTS_STRING)
        ProductDto productDto
) implements Serializable, ProductResponse {

    //TODO: Refactor - annotating constructor instead of Type due to IntelliJ bug
    @Builder
    public ProductByItemNameResponse {
    }
}
