package com.zmart.food.product.dto.Request;

import com.zmart.food.product.validation.ValidAlpha;


public record ProductByItemCodeRequest(
        @ValidAlpha
        String itemCode
) {
}
