package com.zmart.food.product.service;

import com.zmart.food.product.dto.ProductDto;
import com.zmart.food.product.utils.SpecialCaseProductsEnum;
import lombok.experimental.UtilityClass;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.stream.IntStream;

@UtilityClass
public class ProductInventoryServiceImplHelper {

    /**
     * Edge cases to handle special quality items.
     *
     * <p>Some types of items don't follow normal deprecation rules:
     *
     * <p>1. SPECIAL_CASE_1 (example: Corn on the Cob)
     *
     * <p>Quality increments daily by 1 as the sell by date approaches 0 and continues to increase in
     * quality.
     *
     * <p>Will not go-over 50.
     *
     *
     * <p>2. SPECIAL_CASE_2 (example: 3lb Ground Beef)
     *
     * <p>As sell by date approaches, quality increments by 1.
     *
     * <p>Quality increments by 2 when 10 days or less.
     *
     * <p>The quality drops to 0 after the sell by date.
     *
     * <p>3. SPECIAL_CASE_3 (example: Twinkies)
     *
     * <p>Never needs to be sold.
     *
     * <p>Never decreases in quality.
     *
     * <p>
     *
     * @param specialProduct
     * @return Product specialProduct
     */
    static ProductDto handleSpecialQualityProducts(final ProductDto specialProduct) {
        final SpecialCaseProductsEnum enumNumber =
                SpecialCaseProductsEnum.values()[specialProduct.specialCase() - 1];
        switch (enumNumber) {
            case SPECIAL_CASE_1:
                specialProduct.withSellBy(specialProduct.sellBy() - 1);
                specialProduct.withQuality(
                        handleSpecialQualityProductsThatIncreaseQuality(specialProduct.quality() + 1));
                break;
            case SPECIAL_CASE_2:
                specialProduct.withSellBy(specialProduct.sellBy() - 1);
                if (specialProduct.sellBy() < 0) {
                    specialProduct.withQuality(0);
                } else if (specialProduct.sellBy() <= 10) {
                    specialProduct.withQuality(
                            handleSpecialQualityProductsThatIncreaseQuality(specialProduct.quality() + 2));
                } else {
                    specialProduct.withQuality(
                            handleSpecialQualityProductsThatIncreaseQuality(specialProduct.quality() + 1));
                }
                break;
            case SPECIAL_CASE_3:
                break;
        }
        return specialProduct;
    }


    /**
     * Track day-to-day values.
     *
     * <p>An item can never have a negative quality.
     *
     * @param product
     * @param day
     * @return Product product
     */
    static ProductDto updateEachProductQualityAndFutureDate(
            final ProductDto productDto, final Integer day) {
        IntStream.range(0, day).parallel().forEach(i -> endOfEachDayInventoryTracking(productDto, day));
        return productDto;
    }

    /**
     * At the end of each day, quality decrements by 1.
     *
     * <p>At the end of each day, sellBy decrements by 1.
     *
     * <p>Once the sell by date has passed, quality degrades twice as fast.
     *
     * <p>The quality of an item is never more than 50.
     *
     * @param updateProduct
     * @return void
     */
    static void endOfEachDayInventoryTracking(
            final ProductDto updateProduct, final Integer day) {
        updateFutureDate(updateProduct, day);
        if (updateProduct.specialCase() != 0) {
            handleSpecialQualityProducts(updateProduct);
        } else {
            handleRemainingSpecialProducts(updateProduct);
        }
    }

    /**
     * Tracks metrics and offset date.
     *
     * <p>Convert date to LocalDateTime.
     *
     * <p>Add one day.
     *
     * <p>Convert LocalDateTime to date.
     *
     * <p>
     *
     * @param updateProduct
     * @return void
     */
    static void updateFutureDate(final ProductDto updateProduct, final Integer day) {
        final Date currentDate = new Date();
        LocalDateTime localDateTime =
                currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        localDateTime = localDateTime.plusDays(day);
        updateProduct.withFutureDate(
                Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()));
    }

    /**
     * Handle special remaining items.
     *
     * <p>At the end of each day, quality decrements by 1.
     *
     * <p>An item can never have a negative quality.
     *
     * <p>At the end of each day, sellBy decrements by 1.
     *
     * <p>Once the sell by date has passed, quality degrades twice as fast.
     *
     * <p>At the end of each day, quality decrements by 1.
     *
     * <p>The quality of an item is never negative.
     *
     * <p>
     *
     * @param updateProduct
     * @return Product updateProduct
     */
    static ProductDto handleRemainingSpecialProducts(final ProductDto updateProduct) {
        updateProduct.withSellBy(updateProduct.sellBy() - 1);
        if (updateProduct.quality() > 0) {
            endOfDayQualityDegradationStatus(updateProduct);
        }
        return updateProduct;
    }

    /**
     * Quality degrades after sell by date. Calculate this.
     *
     * <p>After sell by date, quality degrades twice as fast.
     *
     * <p>
     *
     * @param updateProduct
     * @return void
     */
    static void endOfDayQualityDegradationStatus(final ProductDto updateProduct) {
        if (updateProduct.sellBy() >= 0) {
            updateProduct.withQuality(updateProduct.quality() - 1);
        } else {
            if (updateProduct.quality() >= 2) {
                updateProduct.withQuality(updateProduct.quality() - 2);
            } else {
                updateProduct.withQuality(updateProduct.quality() - 1);
            }
        }
    }

    /**
     * Edge case to handle special quality items that increase in quality.
     *
     * <p>An item's quality is never more than 50.
     *
     * <p>
     *
     * @param quality
     * @return Integer results
     */
    static Integer handleSpecialQualityProductsThatIncreaseQuality(final Integer quality) {
        Integer result = 50;
        if (quality <= result) {
            result = quality;
        }
        return result;
    }
}
