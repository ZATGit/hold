package com.zmart.food.product.dto.Response;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

import static com.zmart.food.product.utils.UtilConstants.DATA_STRING;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.WRAPPER_OBJECT)
@JsonTypeName(value = DATA_STRING)
public interface ProductResponse {
}
