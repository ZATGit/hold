package com.zmart.food.product.entity;

import com.zmart.food.config.ProductLoggingListener;
import com.zmart.food.product.validation.ValidAlphaWithSpace;
import com.zmart.food.product.validation.ValidPositiveNumeral;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = "Product")
@EntityListeners(ProductLoggingListener.class)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product implements Serializable {
    private static final long serialVersionUID = 1323272533746093028L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @UpdateTimestamp
    @Column(name = "stockDate")
    private Date stockDate;

    @ValidAlphaWithSpace
    @Column(name = "item", nullable = false)
    private String itemName;

    @ValidAlphaWithSpace
    @Column(name = "code", nullable = false)
    private String itemCode;

    @ValidPositiveNumeral
    @Column(name = "sellBy", nullable = false)
    private Integer sellBy;

    @ValidPositiveNumeral
    @Column(name = "quality", nullable = false)
    private Integer quality;

    @NotNull
    @PositiveOrZero
    @Column(name = "specialCase", nullable = false)
    private Integer specialCase;
}
