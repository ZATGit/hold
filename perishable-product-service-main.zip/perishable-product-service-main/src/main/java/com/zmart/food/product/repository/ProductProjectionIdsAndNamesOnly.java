package com.zmart.food.product.repository;

public interface ProductProjectionIdsAndNamesOnly {
    Long getId();

    String getItemName();
}
