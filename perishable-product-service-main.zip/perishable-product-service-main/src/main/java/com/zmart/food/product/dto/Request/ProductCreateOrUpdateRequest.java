package com.zmart.food.product.dto.Request;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.zmart.food.product.validation.ValidUniqueCollection;
import jakarta.validation.constraints.NotNull;

import java.util.List;

import static com.zmart.food.product.utils.UtilConstants.PRODUCTS_STRING;


public record ProductCreateOrUpdateRequest(
        @ValidUniqueCollection
        @JsonAlias(PRODUCTS_STRING)
        List<@NotNull ProductCreateOrUpdateRequestMapping> productList
) {
}


