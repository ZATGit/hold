package com.zmart.food.product.dto.Request;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.zmart.food.product.validation.ValidId;
import com.zmart.food.product.validation.ValidUniqueCollection;

import java.util.List;


public record ProductDeleteRequest(
        @ValidUniqueCollection
        @JsonAlias({"ids", "IDs"})
        List<@ValidId Long> idList) {

}
