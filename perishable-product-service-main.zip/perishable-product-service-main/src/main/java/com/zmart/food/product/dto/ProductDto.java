package com.zmart.food.product.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.zmart.food.product.utils.QualityRequestEnum;
import com.zmart.food.product.validation.ValidAlphaWithSpace;
import com.zmart.food.product.validation.ValidId;
import com.zmart.food.product.validation.ValidPositiveNumeral;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Builder;
import lombok.With;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.util.Date;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;


@JsonPropertyOrder({"id", "stockDate", "futureDate", "itemName",
        "itemCode", "sellBy", "quality", "specialCase"})
@JsonInclude(NON_NULL)
@With
@Builder
public record ProductDto(
        @ValidId
        Long id,
        @UpdateTimestamp
        @JsonFormat(pattern = "MM-dd-yyyy")
        Date stockDate,
        @JsonFormat(pattern = "MM-dd-yyyy")
        Date futureDate,
        @ValidAlphaWithSpace
        String itemName,
        @ValidAlphaWithSpace
        String itemCode,
        @JsonProperty(QualityRequestEnum.QualityRequestConstants.SELL_BY_CONST)
        @ValidPositiveNumeral
        Integer sellBy,
        @ValidPositiveNumeral
        Integer quality,
        @NotNull
        @PositiveOrZero
        Integer specialCase
) implements Serializable {
}
