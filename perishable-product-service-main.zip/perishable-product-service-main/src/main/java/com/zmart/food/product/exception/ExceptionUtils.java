package com.zmart.food.product.exception;

import com.zmart.food.product.utils.SpecialCaseProductsEnum;
import jakarta.validation.ConstraintViolationException;
import lombok.experimental.UtilityClass;
import org.jetbrains.annotations.NotNull;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.Arrays;
import java.util.Objects;

@UtilityClass
// Suppress replace preferred to replaceAll & bitwise operand warnings
@SuppressWarnings({"java:S5361", "java:S2178"})
public class ExceptionUtils {

    private static final String EX_FQN_FILTER_INCLUDE = "com.zmart.food";
    private static final String EX_FQN_FILTER_EXCLUDE = "exception";

    @NotNull
    static String buildResponseForConstraintViolations(final MethodArgumentNotValidException ex) {
        return new StringBuilder(
                StringUtils.trimTrailingCharacter(
                                Objects.requireNonNull(ex.getDetailMessageArguments())[1].toString(), ']'
                        )
                        .replaceFirst("\\[", "")
                        .replaceAll(":", "")
                        .replaceAll("'", "")
        )
                .insert(0, "Invalid properties: ").toString();
    }

    @NotNull
    static String buildResponseForUniqueElementsViolation(final MethodArgumentNotValidException ex) {
        final String invalidField = String.valueOf(ex.getFieldError()).split("'")[3];
        final String[] messageArr = ex.getMessage().split("default message");
        return invalidField.concat(" ").concat(messageArr[messageArr.length - 1]
                .replaceAll("]", "")
                .replaceAll("\\[", "")
                .trim());
    }

    /**
     * Checks whether special case value is allowed to avoid Out of Bounds exception.
     */
    public static void checkProductSpecialCaseAllowed(final Integer... intArgs) {
        Arrays.stream(intArgs)
                .forEach(
                        intArg -> {
                            if (!(intArg <= SpecialCaseProductsEnum.values().length & intArg > -1)) {
                                throw new AppSpecialCaseException();
                            }
                        });
    }

    /**
     * Filters stackTrace elements to:
     *
     * <p>include only project-specific packages &
     *
     * <p>exclude exception classes
     *
     * @param ex
     */
    static StackTraceElement[] filterExceptionTraceElements(final Exception ex) {
        return
                Arrays.stream(ex.getStackTrace())
                        .filter(
                                element ->
                                        element.getClassName().contains(EX_FQN_FILTER_INCLUDE)
                                                && !element.getClassName().contains(EX_FQN_FILTER_EXCLUDE))
                        .toArray(StackTraceElement[]::new);
    }

    // Also used for nestedException on 500 error
    static String getExceptionName(final Exception ex) {
        return ex.getClass().getSimpleName();
    }

    static String getMessage(final Exception ex) {
        return ex.getMessage();
    }

    static String getMethodName(final StackTraceElement[] filteredTrace) {
        if (checkArrayNotEmpty(filteredTrace)) {
            return filteredTrace[0].getMethodName();
        }
        return null;
    }

    static String getMethodCaller(final StackTraceElement[] filteredTrace) {
        if (checkArrayNotEmpty(filteredTrace)) {
            return filteredTrace[1].getMethodName();
        }
        return null;
    }

    static String getDeclaringClass(final StackTraceElement[] filteredTrace) {
        if (checkArrayNotEmpty(filteredTrace)) {
            return filteredTrace[0].getClassName();
        }
        return null;
    }

    /**
     * negative numbers indicate line number unavailable; could be library class -2 indicates native
     * method
     */
    static Integer getLineNumber(final StackTraceElement[] filteredTrace) {
        if (checkArrayNotEmpty(filteredTrace)) {
            return filteredTrace[0].getLineNumber();
        }
        return null;
    }

    static boolean checkArrayNotEmpty(final StackTraceElement[] filteredTrace) {
        return filteredTrace.length > 0;
    }

    /**
     * Helper for handling ConstraintViolationException.
     * Thrown by hibernate-validator violations.
     * Not thrown during entity binding.
     */
    static String getConstraintViolationMessage(final ConstraintViolationException ex) {
        return ex
                .getConstraintViolations()
                .parallelStream()
                .map(violation -> "Property '"
                        .concat(String.valueOf(violation.getPropertyPath()))
                        .concat("' ".concat(violation.getMessage())))
                .toList().get(0);
    }
}
