package com.zmart.food.product.utils;

import com.zmart.food.product.entity.Product;
import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;

import java.util.Date;

import static com.zmart.food.product.utils.UtilConstants.SIMPLE_DATE_FORMAT;

@UtilityClass
public class ProductUtils {

    @SneakyThrows
    public static Date parseDateForJenkinsTimezones(final Date date) {
        return SIMPLE_DATE_FORMAT.parse(SIMPLE_DATE_FORMAT.format(date));
    }

    /**
     * Converts FQDN to class name.
     */
    public static String getClassName(final Class<?> fQDN) {
        final String strFQDN = String.valueOf(fQDN);
        return strFQDN.split("\\.")[strFQDN.split("\\.").length - 1];
    }

    /**
     * <p>Used to reduce builder code duplication when populating DB and mocks for tests
     * while allowing Ids to generate.
     */
    public static Product buildProductWrapper(final Date stockDate, final String itemName,
                                              final String itemCode, final Integer sellBy,
                                              final Integer quality, final Integer specialCase) {
        return Product.builder()
                .stockDate(stockDate)
                .itemName(itemName)
                .itemCode(itemCode)
                .sellBy(sellBy)
                .quality(quality)
                .specialCase(specialCase)
                .build();
    }
}
