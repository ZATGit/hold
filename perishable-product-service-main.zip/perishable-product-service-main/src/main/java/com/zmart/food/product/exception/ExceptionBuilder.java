package com.zmart.food.product.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.annotation.PostConstruct;
import lombok.Builder;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;


@JsonInclude(value = NON_NULL)
@JsonPropertyOrder({"code", "message", "exception", "cause"})
public record ExceptionBuilder(
        String code,
        String message,
        String exception,
        Cause cause
) {
    //TODO: Refactor - annotating constructor instead of Type due to IntelliJ bug
    @Builder
    public ExceptionBuilder {
        cause = validateCause(cause);
    }

    /**
     * <p>Nullifies Cause object if invalid
     * <p>Jackson omits from response if null
     */
    @PostConstruct
    static Cause validateCause(Cause cause) {
        if (cause.message == null && cause.declaringClass == null) {
            cause = null;
        }
        return cause;
    }

    @JsonInclude(NON_NULL)
    @JsonPropertyOrder({"nestedException", "message", "declaringClass",
            "methodName", "methodCaller", "line"})
    static record Cause(
            @JsonProperty("nestedException")
            String nestedException,
            @JsonProperty("message")
            String message,
            @JsonProperty("class")
            String declaringClass,
            @JsonProperty("method")
            String methodName,
            @JsonProperty("caller")
            String methodCaller,
            @JsonProperty("line")
            Integer lineNumber
    ) {

        //TODO: Refactor - annotating constructor instead of Type due to IntelliJ bug
        @Builder
        Cause {
        }
    }
}
