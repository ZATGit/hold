package com.zmart.food.product.dto.Response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.zmart.food.product.repository.ProductProjectionIdsAndNamesOnly;
import com.zmart.food.product.validation.ValidUniqueCollection;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Builder;

import java.util.List;


@JsonPropertyOrder({"count", "deletedProducts"})
public record ProductDeleteResponse(
        @NotNull
        @PositiveOrZero
        Integer count,
        @JsonProperty("deleted")
        @ValidUniqueCollection
        List<@NotNull ProductProjectionIdsAndNamesOnly> deletedProducts
) implements ProductResponse {

    //TODO: Refactor - annotating constructor instead of Type due to IntelliJ bug
    @Builder
    public ProductDeleteResponse {
    }
}
