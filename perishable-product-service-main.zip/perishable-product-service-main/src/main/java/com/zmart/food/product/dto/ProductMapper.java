package com.zmart.food.product.dto;

import com.zmart.food.product.dto.Request.ProductCreateOrUpdateRequestMapping;
import com.zmart.food.product.entity.Product;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface ProductMapper {

    ProductMapper PRODUCT_MAPPER = Mappers.getMapper(ProductMapper.class);

    ProductDto productEntityToProductDto(
            Product productList);

    List<ProductDto> productEntityListToProductDtoList(
            List<Product> productList);

    List<Product> createOrUpdateRequestMappingToProductList(
            List<ProductCreateOrUpdateRequestMapping> productCreateOrUpdateRequestMapping);
}