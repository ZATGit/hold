package com.zmart.food.product.dto.Request;

import com.zmart.food.product.validation.ValidAlphaWithSpace;


public record ProductByItemNameRequest(
        @ValidAlphaWithSpace
        String itemName) {
}
