package com.zmart.food.product.dto.Request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.zmart.food.product.utils.QualityRequestEnum;
import com.zmart.food.product.validation.ValidAlpha;
import com.zmart.food.product.validation.ValidAlphaWithSpace;
import com.zmart.food.product.validation.ValidPositiveNumeral;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import static com.zmart.food.product.utils.QualityRequestEnum.QualityRequestConstants.SELL_BY_CONST;


public record ProductCreateOrUpdateRequestMapping(
        @ValidAlphaWithSpace
        String itemName,
        @ValidAlpha
        String itemCode,
        @ValidPositiveNumeral
        @JsonProperty(SELL_BY_CONST)
        Integer sellBy,
        @ValidPositiveNumeral
        Integer quality,
        @NotNull
        @PositiveOrZero
        Integer specialCase
) {
}
