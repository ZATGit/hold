package com.zmart.food.product.service;

import com.zmart.food.app.PerishableProductApplicationProduct;
import com.zmart.food.product.dto.ProductDto;
import com.zmart.food.product.dto.Request.ProductByItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameOrItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameRequest;
import com.zmart.food.product.dto.Request.ProductByQualityRequest;
import com.zmart.food.product.dto.Request.ProductFutureDateRequest;
import com.zmart.food.product.dto.Response.ProductAllProductsResponse;
import com.zmart.food.product.dto.Response.ProductByItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameOrItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameResponse;
import com.zmart.food.product.dto.Response.ProductByQualityResponse;
import com.zmart.food.product.dto.Response.ProductFutureDateResponse;
import com.zmart.food.product.entity.Product;
import com.zmart.food.product.utils.QualityRequestEnum;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.stream.Collectors;

import static com.zmart.food.product.dto.ProductMapper.PRODUCT_MAPPER;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("Perishable Product Service Impl Product Test")
class PerishableProductServiceImplProductTest extends PerishableProductApplicationProduct {

    @Mock
    private ProductInventoryService productInventoryService;

    @Test
    @DisplayName("Test Mock Creation")
    void testMockCreation() {
        assertNotNull(productInventoryService);
    }

    @Test
    @DisplayName("Test Get All Products Inventory")
    void testGetAllProductsInventory() {
        when(productInventoryService.getAllProductsInventory()).thenReturn(
                ProductAllProductsResponse.builder()
                    .productDtoList(PRODUCT_MAPPER
                            .productEntityListToProductDtoList(MOCK_PRODUCT_LIST))
                    .build());
        assertTrue(productInventoryService
                .getAllProductsInventory().productDtoList().size() > 1);
        verify(productInventoryService, times(1))
                .getAllProductsInventory();
    }

    @Test
    @DisplayName("Test Get All Products For Future Date Inventory")
    void testGetAllProductsForFutureDateInventory() {
        final ProductFutureDateRequest request = mock(ProductFutureDateRequest.class);
        when(productInventoryService.getAllProductsForFutureDateInventory(request))
                .thenReturn(ProductFutureDateResponse.builder()
                        .productDtoList(PRODUCT_MAPPER
                                .productEntityListToProductDtoList(MOCK_PRODUCT_LIST_OFFSET_50_DAYS))
                        .build());
        assertTrue(productInventoryService
                .getAllProductsForFutureDateInventory(request).productDtoList().get(3).quality()
                .equals(80));
        verify(productInventoryService, times(1))
                .getAllProductsForFutureDateInventory(request);
    }

    @Test
    @DisplayName("Test Get Product By Item Name Inventory")
    void testGetProductByItemNameInventory() {
        final String appleGranItemCode = "ApplesGran";
        final Integer applesGranIndex = 2;
        final ProductByItemNameRequest request = mock(ProductByItemNameRequest.class);
        when(productInventoryService.getProductByItemNameInventory(request))
                .thenReturn(ProductByItemNameResponse.builder()
                        .productDto(PRODUCT_MAPPER.productEntityToProductDto(MOCK_PRODUCT_LIST.get(applesGranIndex)))
                        .build());
        assertAll(
                () -> assertTrue(productInventoryService
                        .getProductByItemNameInventory(request).productDto().quality().equals(7)),
                () -> assertTrue(productInventoryService
                        .getProductByItemNameInventory(request).productDto().itemCode().equals(appleGranItemCode))
        );
        verify(productInventoryService, times(2)).getProductByItemNameInventory(request);
    }

    @Test
    @DisplayName("Test Get Product By Item Code Inventory")
    void testGetProductByItemCodeInventory() {
        final String appleGranItemName = "Grannysmith Apple";
        final Integer applesGranIndex = 2;
        final ProductByItemCodeRequest request = mock(ProductByItemCodeRequest.class);
        when(productInventoryService.getProductByItemCodeInventory(request))
                .thenReturn(ProductByItemCodeResponse.builder()
                        .productDto(PRODUCT_MAPPER
                                .productEntityToProductDto(MOCK_PRODUCT_LIST.get(applesGranIndex)))
                        .build());
        assertAll(() -> assertTrue(productInventoryService.getProductByItemCodeInventory(request).productDto().quality().equals(7)),
                () -> assertTrue(productInventoryService.getProductByItemCodeInventory(request).productDto().itemName().equals(appleGranItemName))
        );
        verify(productInventoryService, times(2))
                .getProductByItemCodeInventory(request);
    }

    @Test
    @DisplayName("Test Get Product By Item Name Or Item Code Inventory")
    void testGetProductByItemNameOrItemCodeInventory() {
        final String appleGranItemName = "ApplesGran";
        final Integer applesGranIndex = 2;
        final Integer applesGranQuality = 7;
        final String orgSpinItemName = "Farm2Table Organic Spinach";
        final Integer orgSpinIndex = 0;
        final Integer orgSpinQuality = 20;
        final List<Product> productList = List.of(MOCK_PRODUCT_LIST.get(orgSpinIndex), MOCK_PRODUCT_LIST.get(applesGranIndex));
        final ProductByItemNameOrItemCodeRequest request = mock(ProductByItemNameOrItemCodeRequest.class);
        when(productInventoryService.getProductByItemNameOrItemCodeInventory(request))
                .thenReturn(ProductByItemNameOrItemCodeResponse.builder()
                        .productDtoList(
                                PRODUCT_MAPPER.productEntityListToProductDtoList(productList))
                        .build());
        assertAll(
                () -> assertTrue(productInventoryService.getProductByItemNameOrItemCodeInventory(request)
                        .productDtoList().get(0).quality().equals(orgSpinQuality)),
                () -> productInventoryService.getProductByItemNameOrItemCodeInventory(request)
                        .productDtoList().get(1).quality().equals(applesGranQuality),
                () -> productInventoryService.getProductByItemNameOrItemCodeInventory(request)
                        .productDtoList().get(0).itemName().equals(orgSpinItemName),
                () -> productInventoryService.getProductByItemNameOrItemCodeInventory(request)
                        .productDtoList().get(1).itemName().equals(appleGranItemName));
        verify(productInventoryService, times(4))
                .getProductByItemNameOrItemCodeInventory(request);
    }

    @Test
    @DisplayName("Test Get All Products By Quality Inventory")
    void testGetAllProductsByQualityInventory() {
        final Integer quality = 20;
        final Integer limit = 100;
        final String orderByAttribute = QualityRequestEnum.SELL_BY.name();
        final String orderByAscOrDesc = QualityRequestEnum.ASC.name();
        final ProductByQualityRequest productQualityRequest = new ProductByQualityRequest(quality, 100, orderByAttribute, orderByAscOrDesc);
        when(productInventoryService.getAllProductsByQualityInventory(productQualityRequest))
                .thenReturn(ProductByQualityResponse.builder()
                        .productDtoList(getQualityOfTwenty(quality))
                        .build());
        assertTrue(productInventoryService
                .getAllProductsByQualityInventory(productQualityRequest).productDtoList().size() == 2);
        verify(productInventoryService, times(1))
                .getAllProductsByQualityInventory(productQualityRequest);
    }

    // UTILITY
    private List<ProductDto> getQualityOfTwenty(final Integer quality) {
        return MOCK_PRODUCT_LIST.stream()
                .map(p -> PRODUCT_MAPPER.productEntityToProductDto(p))
                .filter(p -> p.quality()
                        .equals(quality))
                .collect(Collectors.toList());
    }
}
