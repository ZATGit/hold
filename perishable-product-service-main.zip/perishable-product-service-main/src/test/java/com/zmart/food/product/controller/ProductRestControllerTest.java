package com.zmart.food.product.controller;

import com.zmart.food.app.PerishableProductApplicationProduct;
import com.zmart.food.product.dto.ProductDto;
import com.zmart.food.product.dto.Request.ProductByItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameOrItemCodeRequest;
import com.zmart.food.product.dto.Request.ProductByItemNameRequest;
import com.zmart.food.product.dto.Request.ProductByQualityRequest;
import com.zmart.food.product.dto.Request.ProductFutureDateRequest;
import com.zmart.food.product.dto.Response.ProductAllProductsResponse;
import com.zmart.food.product.dto.Response.ProductByItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameOrItemCodeResponse;
import com.zmart.food.product.dto.Response.ProductByItemNameResponse;
import com.zmart.food.product.dto.Response.ProductByQualityResponse;
import com.zmart.food.product.dto.Response.ProductFutureDateResponse;
import com.zmart.food.product.service.ProductInventoryService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.List;
import java.util.stream.Collectors;

import static com.zmart.food.product.dto.ProductMapper.PRODUCT_MAPPER;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@DisplayName("Product Rest Controller Test")
class ProductRestControllerTest extends PerishableProductApplicationProduct {

    private final String itemNameSpinach = "Farm2Table Organic Spinach";

    private final String itemCodeSpinach = "OrgSpinach";

    @Mock
    private MockHttpServletRequest mockHttpServletRequest;

    @Mock
    private ProductInventoryService perishableProductService;

    @InjectMocks
    private ProductRestController perishableProductController;

    // UTILITY
    private static List<ProductDto> getQualityArrayListWithSeven(final Integer quality) {
        return (MOCK_PRODUCT_LIST.stream()
                .map(PRODUCT_MAPPER::productEntityToProductDto)
                .filter(p -> p.quality().equals(quality)))
                .collect(Collectors.toList());
    }

    @BeforeEach
    void setup() {
        final HttpServletRequest mockRequest = new MockHttpServletRequest();
        final ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(mockRequest);
        RequestContextHolder.setRequestAttributes(servletRequestAttributes);
    }

    @AfterEach
    void teardown() {
        RequestContextHolder.resetRequestAttributes();
    }

    @Test
    @DisplayName("Test Perishable Product Controller")
    void testPerishableProductController() {
        assertAll(
                () -> assertNotNull(mockHttpServletRequest),
                () -> assertNotNull(perishableProductService),
                () -> assertNotNull(perishableProductController));
    }

    @Test
    @DisplayName("Test Get All Inventory")
    void testGetAllInventory() {
        when(perishableProductService.getAllProductsInventory())
                .thenReturn(ProductAllProductsResponse.builder()
                        .productDtoList(PRODUCT_MAPPER.productEntityListToProductDtoList(MOCK_PRODUCT_LIST))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getAllProducts();
        final ProductAllProductsResponse resultsBody = (ProductAllProductsResponse) results.getBody();
        assertAll(
                () -> assertTrue((resultsBody.productDtoList()).size() == 5, "Found values"),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode())
        );
    }

    @Test
    @DisplayName("Test Get All Products For Future Date")
    void testGetAllProductsForFutureDate() {
        final ProductFutureDateRequest request = mock(ProductFutureDateRequest.class);
        final Integer dayOffset = 50;
        final String itemName = "CornCob";
        when(perishableProductService.getAllProductsForFutureDateInventory(request))
                .thenReturn(ProductFutureDateResponse.builder()
                        .productDtoList(PRODUCT_MAPPER
                                .productEntityListToProductDtoList(MOCK_PRODUCT_LIST_OFFSET_50_DAYS))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getAllProductsForFutureDate(request);
        final ProductFutureDateResponse resultsBody = (ProductFutureDateResponse) results.getBody();
        assertAll(
                () -> assertTrue(resultsBody
                        .productDtoList().get(1).itemCode().equals(itemName), "Found "),
                () -> assertTrue(resultsBody.productDtoList().get(1).quality().equals(dayOffset)),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode(), "Found ")
        );
    }

    @Test
    @DisplayName("Test Get Product By Item Name")
    void testGetProductByItemName() {
        final ProductByItemNameRequest request = new ProductByItemNameRequest(itemNameSpinach);
        when(perishableProductService.getProductByItemNameInventory(request))
                .thenReturn(ProductByItemNameResponse.builder()
                        .productDto(PRODUCT_MAPPER.productEntityToProductDto(MOCK_PRODUCT_LIST.get(0)))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getProductByItemName(request);
        final ProductByItemNameResponse resultsBody = (ProductByItemNameResponse) results.getBody();
        assertAll(
                () -> assertTrue(resultsBody
                        .productDto().itemName().equals(itemNameSpinach), "Found "),
                () -> assertTrue(resultsBody
                        .productDto().quality().equals(20), "Found "),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode())
        );
    }

    @Test
    @DisplayName("Test Get Product By Item Code")
    void testGetProductByItemCode() {
        final ProductByItemCodeRequest request = new ProductByItemCodeRequest(itemCodeSpinach);
        when(perishableProductService.getProductByItemCodeInventory(request))
                .thenReturn(ProductByItemCodeResponse.builder()
                        .productDto(PRODUCT_MAPPER.productEntityToProductDto(MOCK_PRODUCT_LIST.get(0)))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getProductByItemCode(request);
        final ProductByItemCodeResponse resultsBody = (ProductByItemCodeResponse) results.getBody();
        assertAll(
                () -> assertTrue(resultsBody.productDto().itemCode().equals(itemCodeSpinach), "Found "),
                () -> assertTrue(resultsBody.productDto().quality().equals(20), "Found "),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode()));
    }

    @Test
    @DisplayName("Test Get All Inventory By Quality")
    void testGetAllInventoryByQuality() {
        final ProductByQualityRequest request = mock(ProductByQualityRequest.class);
        final Integer quality = 7;
        when(perishableProductService.getAllProductsByQualityInventory(request))
                .thenReturn(ProductByQualityResponse.builder()
                        .productDtoList(getQualityArrayListWithSeven(quality))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getAllProductsByQuality(request);
        final ProductByQualityResponse resultsBody = (ProductByQualityResponse) results.getBody();
        assertAll(
                () -> assertTrue(resultsBody.productDtoList().size() == 1, "Found "),
                () -> assertTrue(resultsBody.productDtoList().get(0).quality().equals(quality)),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode())
        );
    }

    @Test
    @DisplayName("Test Get Item By Item Name Or Item Code")
    void testGetItemByItemNameOrItemCode() {
        final String itemCodeApples = "CornCob";
        final ProductByItemNameOrItemCodeRequest request = new ProductByItemNameOrItemCodeRequest(itemNameSpinach, itemCodeApples);
        when(perishableProductService.getProductByItemNameOrItemCodeInventory(request))
                .thenReturn(ProductByItemNameOrItemCodeResponse.builder()
                        .productDtoList(
                                PRODUCT_MAPPER.productEntityListToProductDtoList(MOCK_PRODUCT_LIST.subList(0, 2)))
                        .build());
        final ResponseEntity<?> results = perishableProductController.getProductByItemNameOrItemCode(request);
        final ProductByItemNameOrItemCodeResponse resultsBody = (ProductByItemNameOrItemCodeResponse) results.getBody();
        final List<ProductDto> productList = resultsBody.productDtoList();
        assertAll(
                () -> assertTrue((productList).get(0).itemName().contains(itemNameSpinach), "Found "),
                () -> assertTrue((productList).get(1).itemCode().contains(itemCodeApples), "Found "),
                () -> assertEquals(HttpStatus.OK, results.getStatusCode())
        );
    }
}
