package com.zmart.food.app;

import com.zmart.food.product.entity.Product;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.zmart.food.product.utils.ProductUtils.buildProductWrapper;
import static com.zmart.food.product.utils.ProductUtils.parseDateForJenkinsTimezones;

@SuppressWarnings("serial")
public interface MockProductList {
    Date date1L = parseDateForJenkinsTimezones(new Date(1L));
    Date date5L = parseDateForJenkinsTimezones(new Date(5L));
    List<Product> MOCK_PRODUCT_LIST =
            new ArrayList<>() {
                {
                    add(buildProductWrapper(date1L, "Farm2Table Organic Spinach",
                            "OrgSpinach", 10, 20, 0));
                    add(buildProductWrapper(date1L, "Corn on the cob",
                            "CornCob", 2, 0, 1));
                    add(buildProductWrapper(date1L, "Grannysmith Apple",
                            "ApplesGran", 5, 7, 0));
                    add(buildProductWrapper(date1L, "Twinkies",
                            "Twinkies", 0, 80, 3));
                    add(buildProductWrapper(date1L, "3lb Ground Beef",
                            "3lbGrBeed", 15, 20, 2));
                }
            };

    List<Product> MOCK_PRODUCT_LIST_OFFSET_50_DAYS =
            new ArrayList<>() {
                {
                    add(buildProductWrapper(
                            date1L, "Farm2Table Organic Spinach",
                            "OrgSpinach", -40, 0, 0));
                    add(buildProductWrapper(date1L, "Corn on the cob",
                            "CornCob", -48, 50, 1));
                    add(buildProductWrapper(date1L, "Grannysmith Apple",
                            "ApplesGran", -45, 0, 0));
                    add(buildProductWrapper(date1L, "Twinkies",
                            "Twinkies", 0, 80, 2));
                    add(buildProductWrapper(date1L, "3lb Ground Beef",
                            "3lbGrBeed", -35, 0, 3));
                }
            };
}
